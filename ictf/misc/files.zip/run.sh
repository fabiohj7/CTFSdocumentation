#!/bin/bash

gdb -x /home/user/gdbinit
